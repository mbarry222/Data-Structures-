import timeit
from src.Stack.LinkedStack import LinkedStack


def push_stack(stack, n):
    for i in range(n):
        stack.push(i)


def pop_stack(stack):
    for i in range(n):
        stack.pop()


def peek_stack(stack):
    for i in range(n):
        stack.peek()


def benchmark_stack_operations(n):
    stack = LinkedStack()
    push_time = timeit.timeit(lambda: push_stack(stack, n), number=10)
    peek_time = timeit.timeit(lambda: peek_stack(stack), number=10)
    pop_time = timeit.timeit(lambda: pop_stack(stack), number=10)
    print(f"Operations on {n} elements:")
    print(f"Push Time: {push_time:.5f} seconds")
    print(f"Peek Time: {peek_time:.5f} seconds")
    print(f"Pop Time: {pop_time:.5f} seconds")


if __name__ == "__main__":
    for n in [50, 100, 500, 1000, 5000, 10000, 50000,100000]:
        benchmark_stack_operations(n)
