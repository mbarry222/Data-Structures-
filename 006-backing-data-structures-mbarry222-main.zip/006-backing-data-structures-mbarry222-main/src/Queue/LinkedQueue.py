from abc import ABC, abstractmethod


class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class AbstractQueue(ABC):
    @abstractmethod
    def enqueue(self, item):
        pass

    @abstractmethod
    def dequeue(self):
        pass

    @property
    @abstractmethod
    def is_empty(self):
        pass

    @property
    @abstractmethod
    def size(self):
        pass

class LinkedQueue(AbstractQueue):
    def __init__(self):
        self.front = None
        self.rear = None
        self._size = 0

    def enqueue(self, item):
        """Add an item to the rear of the queue."""
        new_node = Node(item)
        if self.is_empty:
            self.front = self.rear = new_node
        else:
            self.rear.next = new_node
            self.rear = new_node
        self._size += 1

    def dequeue(self):
        """Remove and return the item from the front of the queue."""
        if self.is_empty:
            raise IndexError("Dequeue from an empty queue")
        result = self.front.data
        self.front = self.front.next
        if self.front is None:
            self.rear = None
        self._size -= 1
        return result

    @property
    def is_empty(self):
        """Return True if the queue is empty, False otherwise."""
        return self.front is None

    @property
    def size(self):
        """Return the number of items in the queue."""
        return self._size