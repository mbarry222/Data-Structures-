import timeit
from src.Queue.LinkedQueue import LinkedQueue


def enqueue_queue(queue, n):
    for i in range(n):
        queue.enqueue(i)

def dequeue_queue(queue):
    while not queue.is_empty:
        queue.dequeue()

def benchmark_queue_operations(n):
    queue = LinkedQueue()
    enqueue_time = timeit.timeit(lambda: enqueue_queue(queue, n), number=100)
    dequeue_time = timeit.timeit(lambda: dequeue_queue(queue), number=100)
    print(f"Operations on {n} elements:")
    print(f"Enqueue Time: {enqueue_time:.5f} seconds")
    print(f"Dequeue Time: {dequeue_time:.5f} seconds")

if __name__ == "__main__":
    for n in [50,100, 500, 1000, 5000, 10000,50000,100000]:
        benchmark_queue_operations(n)



