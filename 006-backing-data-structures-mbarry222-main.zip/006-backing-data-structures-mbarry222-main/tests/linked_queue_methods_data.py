import timeit
from src.Queue.LinkedQueue import LinkedQueue

def enqueue_elements(queue, num_elements):
    for i in range(num_elements):
        queue.enqueue(i)

def dequeue_elements(queue, num_elements):
    while not queue.is_empty:
        queue.dequeue()

def benchmark_linked_queue(num_elements):
    queue = LinkedQueue()
    enqueue_time = timeit.timeit(
        stmt=lambda: enqueue_elements(queue, num_elements),
        number=10
    )


    queue = LinkedQueue()
    enqueue_elements(queue, num_elements)
    dequeue_time = timeit.timeit(
        stmt=lambda: dequeue_elements(queue, num_elements),
        number=10
    )

    print(f"Testing with {num_elements} elements:")
    print(f"Enqueue Time: {enqueue_time:.5f} seconds")
    print(f"Dequeue Time: {dequeue_time:.5f} seconds")

if __name__ == "__main__":
    for num in [50,100, 500, 1000, 5000, 10000,50000,100000]:
        benchmark_linked_queue(num)