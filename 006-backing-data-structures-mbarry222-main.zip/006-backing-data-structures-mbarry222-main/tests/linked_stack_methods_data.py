import timeit
from src.Stack.LinkedStack import LinkedStack

def setup_stack(num_elements):
    stack = LinkedStack()
    for i in range(num_elements):
        stack.push(i)
    return stack

def benchmark_push(num_elements):
    stack = LinkedStack()
    return timeit.timeit(lambda: stack.push(1), number=10000)

def benchmark_pop(num_elements):
    stack = setup_stack(num_elements)
    if stack.is_empty:
        return 0
    return timeit.timeit(lambda: stack.pop() if not stack.is_empty else None, number=10000)
def benchmark_peek(num_elements):
    stack = setup_stack(num_elements)
    if stack.is_empty:
        return 0
    return timeit.timeit(lambda: stack.peek(), number=10000)


def run_benchmarks():
    print("Benchmarking LinkedStack Operations:")
    for num_elements in [50,100, 500, 1000, 5000, 10000,50000,100000]:
        push_time = benchmark_push(num_elements)
        pop_time = benchmark_pop(num_elements)
        peek_time = benchmark_peek(num_elements)
        print(
            f"{num_elements} Elements - Push Time: {push_time:.5f} seconds, Pop Time: {pop_time:.5f} seconds, Peek Time: {peek_time:.5f} seconds")


if __name__ == "__main__":
    run_benchmarks()